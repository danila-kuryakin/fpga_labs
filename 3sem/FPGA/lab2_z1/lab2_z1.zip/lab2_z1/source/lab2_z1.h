#define ROWS 3

typedef short 	din_type;
typedef int 	dout_type;

dout_type lab2_z1 (din_type in);
