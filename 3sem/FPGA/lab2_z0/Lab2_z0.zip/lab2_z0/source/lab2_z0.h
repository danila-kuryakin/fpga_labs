#define ROWS 3

typedef short 	din_type;
typedef int 	dout_type;

// Prototype of top level function for C-synthesis
void lab2_z0 (din_type in_a[ROWS], din_type in_b[ROWS], dout_type res[ROWS]);
