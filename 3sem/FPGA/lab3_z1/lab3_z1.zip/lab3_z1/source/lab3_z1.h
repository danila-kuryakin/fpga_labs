#define ROWS 3

typedef short 	data_in, pnt_in;
typedef int 	pnt_out, data_ret;

data_ret lab3_z1 (data_in inA, data_in inB, pnt_in *inC, pnt_out *res);
